import sys
import os
import time
import json
import re
import hashlib
import urllib.parse
import threading
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime, timedelta, timezone

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import requests

CONFIG_URL = "https://raw.githubusercontent.com/tvstreamx/tvstreamx/refs/heads/main/jsons/config.json"
NEXT_PAGE_ICON = 'https://raw.githubusercontent.com/tvstreamx/tvstreamx/refs/heads/main/imagens/proximo.png'
QR_CODE_ICON = 'https://raw.githubusercontent.com/tvstreamx/tvstreamx/refs/heads/main/qrcode.png'
TMDB_IMAGE_BASE_URL = 'https://image.tmdb.org/t/p/'

JUNK_WORDS = {
    'cinema', 'cam', 'ts', 'leg', 'legendado', 'dub', 'dublado', 'l', 'hd', 'fhd', 'sd',
    'uhd', '4k', 'h264', 'h265', 'fhd h264', 'fhd h265', 'x264', 'x265', '720p',
    '1080p', '2160p'
}

RE_NORM_YEAR = re.compile(r'\s*\(\d{4}\)\s*')
RE_NORM_SPECIAL_CHARS = re.compile(r'[^a-z0-9\s]')
RE_SEARCH_ACCENTS = [
    (re.compile(r'[áàâãä]'), 'a'), (re.compile(r'[éèêë]'), 'e'),
    (re.compile(r'[íìîï]'), 'i'), (re.compile(r'[óòôõö]'), 'o'),
    (re.compile(r'[úùûü]'), 'u'), (re.compile(r'[ç]'), 'c')
]
RE_SEARCH_SPECIAL_CHARS = re.compile(r'[^a-z0-9]')

class Addon:
    def __init__(self, argv):
        self.addon = xbmcaddon.Addon()
        self.base_url = argv[0]
        self.handle = int(argv[1])
        self.params = dict(urllib.parse.parse_qsl(argv[2][1:]))
        self.config = None
        self.is_initialized = False
        self._setup_paths()
        self.is_initialized = self._initialize_addon()

    def _setup_paths(self):
        self.addon_install_path = xbmcvfs.translatePath(self.addon.getAddonInfo('path'))
        self.base_cache_path = os.path.join(self.addon_install_path, 'arquivos', 'cache')
        self.api_cache_path = os.path.join(self.base_cache_path, 'api')
        self.maps_cache_path = os.path.join(self.base_cache_path, 'maps')
        self.epg_cache_path = os.path.join(self.base_cache_path, 'epg')
        for path in [self.api_cache_path, self.maps_cache_path, self.epg_cache_path]:
            if not xbmcvfs.exists(path):
                xbmcvfs.mkdirs(path)

    def _initialize_addon(self):
        if not self._load_remote_config():
            xbmcgui.Dialog().ok("Erro Crítico", "Não foi possível carregar as configurações remotas. O addon não pode continuar.")
            return False
        if not self._check_for_updates():
            return False
        self._check_and_update_maps_background()
        return True
    
    def _load_remote_config(self):
        try:
            response = requests.get(CONFIG_URL, timeout=10)
            response.raise_for_status()
            self.config = response.json()
            api_config = self.config['api']
            self.CINEPULSE_BASE_API = f"http://{api_config['host']}/player_api.php?username={api_config['username']}&password={api_config['password']}&action="
            self.TMDB_API_KEY = api_config['tmdb']
            self.PLAY_URL_TEMPLATES = {
                'movie': f"http://{api_config['host']}/movie/{api_config['username']}/{api_config['password']}/{{id}}.mp4",
                'series': f"http://{api_config['host']}/series/{api_config['username']}/{api_config['password']}/{{id}}.mp4",
                'live': f"http://{api_config['host']}/live/{api_config['username']}/{api_config['password']}/{{id}}.ts",
            }
            self.EPG_URLS = [f"http://{api_config['host']}/xmltv.php?username={api_config['username']}&password={api_config['password']}", 'https://raw.githubusercontent.com/limaalef/BrazilTVEPG/refs/heads/main/epg.xml']
            return True
        except Exception as e:
            xbmc.log(f"Failed to load remote config: {e}", level=xbmc.LOGERROR)
            self.config = None
            return False
            
    def _check_for_updates(self):
        try:
            local_version_str = self.addon.getAddonInfo('version')
            update_info = self.config.get('update', {})
            remote_version_str = update_info.get('version')

            if not remote_version_str or not update_info.get('url'):
                return True 

            local_version = tuple(map(int, local_version_str.split('.')))
            remote_version = tuple(map(int, remote_version_str.split('.')))

            if remote_version > local_version:
                dialog = xbmcgui.Dialog()
                choice = dialog.yesno(
                    "Atualização Obrigatória",
                    f"Uma nova versão ({remote_version_str}) é necessária para continuar.\n"
                    f"Sua versão atual é: {local_version_str}\n\n"
                    "Deseja atualizar agora?",
                    yeslabel="Atualizar Agora", nolabel="Sair do Addon"
                )

                if choice:
                    self._install_update(update_info['url'])
                
                return False

            return True

        except Exception as e:
            xbmc.log(f"Error checking for updates: {e}", level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Erro de Atualização", f"Não foi possível verificar por novas versões.\nErro: {e}")
            return True

    def _wipe_addon_directory(self):
        """Apaga todo o conteúdo do diretório do addon para uma instalação limpa."""
        xbmc.log(f"LIMPANDO DIRETÓRIO DO ADDON: {self.addon_install_path}", level=xbmc.LOGWARNING)
        try:
            addon_path = self.addon_install_path
            dirs, files = xbmcvfs.listdir(addon_path)
            
            for file_to_delete in files:
                xbmcvfs.delete(os.path.join(addon_path, file_to_delete))
                
            for dir_to_delete in dirs:
                xbmcvfs.rmdir(os.path.join(addon_path, dir_to_delete), force=True)
                
            xbmc.log("Limpeza do diretório do addon concluída.", level=xbmc.LOGINFO)
            return True
        except Exception as e:
            xbmc.log(f"CRÍTICO: Falha ao limpar o diretório do addon: {e}", level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Erro Crítico na Atualização", f"Falha ao limpar arquivos antigos: {e}. O addon pode estar corrompido. Reinstale manualmente.")
            return False

    def _install_update(self, url):
        """
        Baixa a atualização, apaga todos os arquivos antigos, extrai a nova versão
        e reinicia o Kodi.
        """
        dialog = xbmcgui.DialogProgress()
        dialog.create("Atualizando Addon", "Iniciando processo...")
        temp_zip_path = os.path.join(xbmcvfs.translatePath('special://home/temp'), 'addon_update.zip')
        
        try:
            # 1. Download do arquivo ZIP
            dialog.update(0, "Baixando nova versão...")
            with requests.get(url, stream=True, allow_redirects=True, timeout=30) as r:
                r.raise_for_status()
                total_size = int(r.headers.get('content-length', 0))
                downloaded = 0
                with open(temp_zip_path, 'wb') as f:
                    for chunk in r.iter_content(chunk_size=8192):
                        f.write(chunk)
                        downloaded += len(chunk)
                        if total_size > 0:
                            percent = int(downloaded * 100 / total_size)
                            dialog.update(percent, f"Baixando... {percent}%")
                        if dialog.iscanceled():
                            dialog.close()
                            return
            
            # 2. Limpeza COMPLETA do diretório do addon
            dialog.update(100, "Download concluído. Limpando arquivos antigos...")
            if not self._wipe_addon_directory():
                dialog.close()
                return # Aborta a atualização se a limpeza falhar

            # 3. Extração manual dos arquivos do ZIP para o diretório agora vazio
            dialog.update(100, "Extraindo arquivos...")
            addon_id = self.addon.getAddonInfo('id')
            destination_path = self.addon_install_path
            
            with zipfile.ZipFile(temp_zip_path, 'r') as zip_ref:
                for member in zip_ref.infolist():
                    if member.is_dir():
                        continue
                    
                    parts = member.filename.split('/', 1)
                    target_filename = parts[1] if len(parts) > 1 and parts[0] == addon_id else member.filename

                    if not target_filename:
                        continue
                        
                    final_destination = os.path.join(destination_path, target_filename)
                    parent_dir = os.path.dirname(final_destination)
                    if not xbmcvfs.exists(parent_dir):
                        xbmcvfs.mkdirs(parent_dir)
                    
                    with zip_ref.open(member) as source_file, xbmcvfs.File(final_destination, 'wb') as target_file:
                        target_file.write(source_file.read())

            # 4. Notifica o usuário e reinicia o Kodi
            dialog.update(100, "Atualização concluída! O Kodi será reiniciado...")
            xbmc.sleep(2500)
            
            xbmc.executebuiltin("RestartApp")

        except Exception as e:
            xbmc.log(f"Update failed: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Falha na Atualização", f"Não foi possível baixar ou instalar a atualização.\nErro: {e}")
        finally:
            if xbmcvfs.exists(temp_zip_path):
                xbmcvfs.delete(temp_zip_path)
            
            if not dialog.iscanceled():
                dialog.close()

    def _make_request(self, url, headers=None, timeout=45, is_json=True):
        try:
            dns_result = self._resolve_dns(url, headers)
            if not dns_result or not dns_result.get('url'):
                xbmc.log(f"DNS resolution failed for {url}", level=xbmc.LOGERROR)
                return None
            response = requests.get(dns_result['url'], headers=dns_result['headers'], timeout=timeout)
            response.raise_for_status()
            return response.json() if is_json else response
        except requests.exceptions.RequestException as e:
            xbmc.log(f"Request failed for {url}: {e}", level=xbmc.LOGERROR)
        except json.JSONDecodeError as e:
            xbmc.log(f"JSON decode error for {url}: {e}", level=xbmc.LOGERROR)
        return None

    def get_json_from_url(self, url, cache_duration_hours=2, cache_path=None):
        cache_path = cache_path or self.api_cache_path
        cache_filename = hashlib.md5(url.encode('utf-8')).hexdigest() + '.json'
        cache_filepath = os.path.join(cache_path, cache_filename)
        if xbmcvfs.exists(cache_filepath):
            try:
                file_stat = xbmcvfs.Stat(cache_filepath)
                if (time.time() - file_stat.st_mtime()) < (cache_duration_hours * 3600):
                    with xbmcvfs.File(cache_filepath, 'r') as f:
                        return json.load(f)
            except Exception as e:
                xbmc.log(f"Failed to read from cache file {cache_filepath}: {e}", level=xbmc.LOGERROR)
        data = self._make_request(url, is_json=True)
        if data:
            try:
                with xbmcvfs.File(cache_filepath, 'w') as f:
                    f.write(json.dumps(data, ensure_ascii=False, indent=4))
            except Exception as e:
                xbmc.log(f"Failed to write to cache file {cache_filepath}: {e}", level=xbmc.LOGERROR)
        return data

    def _normalize_title(self, title):
        clean_title = str(title).lower()
        clean_title = RE_NORM_YEAR.sub('', clean_title)
        clean_title = RE_NORM_SPECIAL_CHARS.sub('', clean_title)
        words = clean_title.split()
        core_words = [word for word in words if word not in JUNK_WORDS]
        return ''.join(core_words)

    def _normalize_for_search(self, text):
        text = str(text).lower()
        for pattern, replacement in RE_SEARCH_ACCENTS:
            text = pattern.sub(replacement, text)
        return RE_SEARCH_SPECIAL_CHARS.sub('', text)

    def _update_map(self, api_action, map_filename, id_key, name_key='name'):
        data = self.get_json_from_url(self.CINEPULSE_BASE_API + api_action, cache_duration_hours=12)
        if not data: return
        map_filepath = os.path.join(self.maps_cache_path, map_filename)
        existing_map = {}
        if xbmcvfs.exists(map_filepath):
            try:
                with xbmcvfs.File(map_filepath, 'r') as f: existing_map = json.load(f)
            except Exception: pass
        new_map = {}
        for stream in data:
            original_name = stream.get(name_key)
            normalized_title = self._normalize_title(original_name)
            item_id = stream.get(id_key)
            if normalized_title and item_id:
                if normalized_title not in new_map:
                    new_map[normalized_title] = []
                source_obj = {'id': item_id, 'name': original_name}
                if source_obj not in new_map[normalized_title]:
                    new_map[normalized_title].append(source_obj)
        existing_map.update(new_map)
        with xbmcvfs.File(map_filepath, 'w') as f:
            f.write(json.dumps(existing_map, ensure_ascii=False, indent=4))
        xbmc.executebuiltin(f'Window.clearProperty(tvstreamx.{map_filename}.updating)')

    def _update_epg_map(self):
        channel_info, program_data = {}, {}
        for url in self.EPG_URLS:
            try:
                xbmc.log(f"Fetching EPG from: {url}", level=xbmc.LOGINFO)
                response = self._make_request(url, timeout=60, is_json=False)
                if not response: continue
                root = ET.fromstring(response.content)
                for channel_elem in root.findall('channel'):
                    channel_id = channel_elem.get('id')
                    display_name_elem = channel_elem.find('display-name')
                    if not channel_id or display_name_elem is None: continue
                    if channel_id not in channel_info:
                        icon_elem = channel_elem.find('icon')
                        channel_info[channel_id] = {'name': display_name_elem.text or '', 'icon': icon_elem.get('src', '') if icon_elem is not None else ''}
                for prog_elem in root.findall('programme'):
                    prog_channel_id = prog_elem.get('channel')
                    if prog_channel_id:
                        if prog_channel_id not in program_data: program_data[prog_channel_id] = []
                        program_data[prog_channel_id].append(prog_elem)
            except Exception as e:
                xbmc.log(f"Failed to process EPG from {url}: {e}", level=xbmc.LOGERROR)
        final_epg_map = {}
        now_utc = datetime.now(timezone.utc)
        for channel_id, info in channel_info.items():
            channel_name = info.get('name')
            if not channel_name: continue
            normalized_name = self._normalize_title(channel_name)
            if normalized_name in final_epg_map: continue
            schedule, processed_programs = [], set()
            for prog in program_data.get(channel_id, []):
                start_str, stop_str = prog.get('start'), prog.get('stop')
                if not start_str or not stop_str: continue
                try:
                    start_time = datetime.strptime(start_str, '%Y%m%d%H%M%S %z')
                    stop_time = datetime.strptime(stop_str, '%Y%m%d%H%M%S %z')
                except ValueError: continue
                if stop_time > now_utc:
                    title_elem = prog.find('title')
                    title = (title_elem.text or "Sem Informação").replace(" - ao vivo", "")
                    program_key = (start_time, title)
                    if program_key in processed_programs: continue
                    processed_programs.add(program_key)
                    desc_elem = prog.find('desc')
                    schedule.append({'title': title, 'description': desc_elem.text if desc_elem is not None else '', 'start_str': start_time.isoformat(), 'end_str': stop_time.isoformat(), 'icon': info.get('icon', '')})
            if schedule:
                schedule.sort(key=lambda x: x['start_str'])
                final_epg_map[normalized_name] = schedule
        map_filepath = os.path.join(self.epg_cache_path, 'epg_map.json')
        with xbmcvfs.File(map_filepath, 'w') as f: f.write(json.dumps(final_epg_map, ensure_ascii=False, indent=4))
        xbmc.executebuiltin('Window.clearProperty(tvstreamx.epg_map.json.updating)')

    def _check_and_update_maps_background(self):
        window = xbmcgui.Window(10000)
        maps_to_check = [
            ('get_vod_streams', 'vod_map.json', 'stream_id', 'name', self._update_map),
            ('get_series', 'series_map.json', 'series_id', 'name', self._update_map),
            ('get_live_streams', 'live_map.json', 'stream_id', 'name', self._update_map),
            (None, 'epg_map.json', None, None, self._update_epg_map)
        ]
        for api_action, map_file, id_key, name_key, target_func in maps_to_check:
            cache_dir = self.epg_cache_path if map_file == 'epg_map.json' else self.maps_cache_path
            map_filepath = os.path.join(cache_dir, map_file)
            update_needed = False
            if not xbmcvfs.exists(map_filepath):
                update_needed = True
            elif map_file == 'epg_map.json' and (time.time() - xbmcvfs.Stat(map_filepath).st_mtime()) > (6 * 3600):
                update_needed = True
            if update_needed and window.getProperty(f'tvstreamx.{map_file}.updating') != 'true':
                window.setProperty(f'tvstreamx.{map_file}.updating', 'true')
                args = (api_action, map_file, id_key, name_key) if api_action else ()
                threading.Thread(target=target_func, args=args).start()

    def list_categories(self):
        xbmcplugin.setContent(self.handle, 'movies')
        categorias_url = "https://raw.githubusercontent.com/tvstreamx/tvstreamx/refs/heads/main/arquivos/categorias.json"
        data = self.get_json_from_url(categorias_url, cache_duration_hours=24)
        if data:
            for categoria in data.get('categorias', []):
                li = xbmcgui.ListItem(label=categoria.get('nome'))
                li.setInfo('video', {'title': categoria.get('nome'), 'plot': categoria.get('descricao')})
                li.setArt({'icon': categoria.get('icon'), 'thumb': categoria.get('icon'), 'fanart': categoria.get('background')})
                url = self._get_plugin_url(action='list_subcategories', url=categoria.get('subcategoria'), parent_id=categoria.get('id'))
                xbmcplugin.addDirectoryItem(handle=self.handle, url=url, listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(self.handle)

    def list_subcategories(self, url, parent_id):
        xbmcplugin.setContent(self.handle, 'movies')
        if str(parent_id) == '1':
            li_search = xbmcgui.ListItem(label='Pesquisar')
            icon_url = 'https://raw.githubusercontent.com/tvstreamx/tvstreamx/refs/heads/main/imagens/pesquisar.png'
            li_search.setArt({'icon': icon_url, 'thumb': icon_url})
            search_url = self._get_plugin_url(action='search_all_live')
            xbmcplugin.addDirectoryItem(handle=self.handle, url=search_url, listitem=li_search, isFolder=True)
        data = self.get_json_from_url(url, cache_duration_hours=24)
        if not data:
            xbmcplugin.endOfDirectory(self.handle)
            return
        used_tmdb_ids = set()
        for subcategoria in data.get('subcategorias', []):
            nome, icon, fanart, prog_url = subcategoria.get('nome'), subcategoria.get('icon'), subcategoria.get('background'), subcategoria.get('programacao')
            if str(parent_id) != '1' and not icon and prog_url and '{realizarbusca}' not in prog_url:
                api_data = self.get_json_from_url(prog_url, cache_duration_hours=3)
                if api_data and api_data.get('results'):
                    for item in api_data['results']:
                        tmdb_id = item.get('id')
                        if tmdb_id and tmdb_id not in used_tmdb_ids:
                            if item.get('poster_path'): icon = TMDB_IMAGE_BASE_URL + 'w500' + item['poster_path']
                            if item.get('backdrop_path'): fanart = TMDB_IMAGE_BASE_URL + 'original' + item['backdrop_path']
                            used_tmdb_ids.add(tmdb_id)
                            break
            li = xbmcgui.ListItem(label=nome)
            li.setInfo('video', {'title': nome, 'plot': subcategoria.get('descricao')})
            li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
            next_url = self._get_plugin_url(action='list_content', url=prog_url, parent_id=parent_id)
            xbmcplugin.addDirectoryItem(handle=self.handle, url=next_url, listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(self.handle)

    def _get_raw_epg_for_pids(self, pids):
        if not pids: return []
        pid_key = ','.join(sorted(map(str, pids)))
        cache_key = hashlib.md5(pid_key.encode('utf-8')).hexdigest() + '.raw_epg.json'
        cache_filepath = os.path.join(self.epg_cache_path, cache_key)
        if xbmcvfs.exists(cache_filepath):
            file_stat = xbmcvfs.Stat(cache_filepath)
            if (time.time() - file_stat.st_mtime()) < 21600:
                with xbmcvfs.File(cache_filepath, 'r') as f:
                    return json.load(f)
        current_time = datetime.now()
        start_time = int(current_time.replace(hour=0, minute=0, second=0, microsecond=0).timestamp())
        end_time = int((current_time + timedelta(days=1)).replace(hour=23, minute=59, second=59).timestamp())
        pid_list = ','.join(map(str, pids))
        epg_url = f"https://contentapi-br.cdn.telefonica.com/25/default/pt-BR/schedules?ca_deviceTypes=null%7C401&ca_channelmaps=147%7Cnull&fields=Pid,Title,Description,ChannelName,Start,End,LiveChannelPid,Images.VideoFrame,Images.banner&orderBy=START_TIME:a&filteravailability=false&starttime={start_time}&endtime={end_time}&livechannelpids={pid_list}&offset=0&limit=2000"
        data = self.get_json_from_url(epg_url, cache_duration_hours=6)
        raw_epg_data = data.get("Content", []) if data else []
        with xbmcvfs.File(cache_filepath, 'w') as f:
            f.write(json.dumps(raw_epg_data))
        return raw_epg_data

    def _process_raw_epg(self, raw_epg_list):
        epg_data, now = {}, int(time.time())
        for item in raw_epg_list:
            if item.get("Start", 0) <= now <= item.get("End", 0):
                pid = item.get("LiveChannelPid")
                if pid:
                    start, end = datetime.fromtimestamp(item.get("Start", 0)), datetime.fromtimestamp(item.get("End", 0))
                    images = item.get("Images", {})
                    video_frame = images.get("VideoFrame", [])
                    thumb_url = video_frame[0].get("Url", "") if video_frame else ""
                    banner = images.get("banner", [])
                    fanart_url = next((img.get("Url") for img in banner if img.get("Url")), "") if banner else ""
                    title = (item.get("Title", "")).replace(" - ao vivo", "")
                    epg_data[pid] = {"title": title, "description": item.get("Description", "").replace("Programação:", "").strip(), "schedule": f"{start.strftime('%H:%M')} às {end.strftime('%H:%M')}", "thumb": thumb_url, "fanart": fanart_url}
        return epg_data

    def _get_consolidated_epg_data(self):
        map_filepath = os.path.join(self.epg_cache_path, 'epg_map.json')
        if not xbmcvfs.exists(map_filepath): return {}
        try:
            with xbmcvfs.File(map_filepath, 'r') as f:
                return json.load(f)
        except Exception as e:
            xbmc.log(f"Could not load EPG map: {e}", level=xbmc.LOGERROR)
            return {}

    def _get_tmdb_fanart_for_title(self, title):
        if not title or title == "Sem Informação": return ""
        try:
            search_query = urllib.parse.quote_plus(title)
            tmdb_search_url = f"https://api.themoviedb.org/3/search/multi?api_key={self.TMDB_API_KEY}&language=pt-BR&query={search_query}"
            data = self.get_json_from_url(tmdb_search_url, cache_duration_hours=72)
            if data and data.get('results') and data['results'][0].get('backdrop_path'):
                return TMDB_IMAGE_BASE_URL + 'original' + data['results'][0]['backdrop_path']
        except Exception as e:
            xbmc.log(f"Error fetching TMDB fanart for '{title}': {e}", level=xbmc.LOGERROR)
        return ""

    def _create_live_channel_list_item(self, channel_name_variants, sources, channel_logo, pid, api_epg_processed, xml_epg_data):
        first_channel_name = channel_name_variants.split(',')[0].strip()
        li = xbmcgui.ListItem(first_channel_name)
        li.setProperty('IsPlayable', 'true')
        plot_text, program_thumb, program_fanart = "", channel_logo, ""
        current_program_title = "Sem Informação"
        now = datetime.now(timezone.utc)
        if pid and pid != '0' and pid in api_epg_processed:
            current_program = api_epg_processed.get(pid)
            current_program_title = current_program.get('title')
            plot_text = f"[B]{current_program_title}[/B] - {current_program.get('schedule')}\n\n{current_program.get('description')}"
            program_thumb = current_program.get('thumb') or channel_logo
            program_fanart = current_program.get('fanart', '')
        else:
            schedule = None
            for name_variant in channel_name_variants.split(','):
                normalized_variant = self._normalize_title(name_variant.strip())
                if normalized_variant in xml_epg_data:
                    schedule = xml_epg_data[normalized_variant]
                    break
            if schedule:
                current_program = next((prog for prog in schedule if datetime.fromisoformat(prog['start_str']) <= now <= datetime.fromisoformat(prog['end_str'])), None)
                if current_program:
                    current_program_title = current_program['title']
                    start_t = datetime.fromisoformat(current_program['start_str']).astimezone()
                    end_t = datetime.fromisoformat(current_program['end_str']).astimezone()
                    schedule_str = f"{start_t.strftime('%H:%M')} às {end_t.strftime('%H:%M')}"
                    plot_text = f"[B]{current_program_title}[/B] - {schedule_str}\n\n{current_program['description']}"
                    program_thumb = current_program.get('icon') or channel_logo
        if not program_fanart:
            program_fanart = self._get_tmdb_fanart_for_title(current_program_title)
        li.setInfo('video', {'title': first_channel_name, 'plot': plot_text, 'mediatype': 'channel'})
        li.setArt({'thumb': program_thumb, 'icon': channel_logo, 'fanart': program_fanart})
        epg_url = self._get_plugin_url(action='list_epg_for_channel', channel_name=channel_name_variants)
        li.addContextMenuItems([('Programação', f'Container.Update({epg_url})')])
        play_url = self._get_plugin_url(action='play_item', item_type='live', sources_json=json.dumps(sources), title=first_channel_name)
        xbmcplugin.addDirectoryItem(handle=self.handle, url=play_url, listitem=li, isFolder=False)

    def list_content(self, url, parent_id):
        xbmcplugin.setContent(self.handle, 'movies')
        if str(parent_id) == '1':
            self._list_live_channels(url)
        elif str(parent_id) == '2':
            self._list_filtered_content(url, parent_id, 'vod_map.json', 'movie')
        elif str(parent_id) == '3':
            self._list_filtered_content(url, parent_id, 'series_map.json', 'tv')

    def search_all_live(self):
        keyboard = xbmc.Keyboard('', 'Pesquisar em Todos os Canais')
        keyboard.doModal()
        if not (keyboard.isConfirmed() and keyboard.getText()): return
        query_text = keyboard.getText()
        search_terms = [self._normalize_for_search(term) for term in query_text.split() if term]
        if not search_terms: return
        map_filepath = os.path.join(self.maps_cache_path, 'live_map.json')
        if not xbmcvfs.exists(map_filepath):
            xbmcgui.Dialog().notification('Aguarde', 'Base de canais ainda em formação.', xbmcgui.NOTIFICATION_INFO, 3000)
            return
        with xbmcvfs.File(map_filepath, 'r') as f: content_map = json.load(f)
        xml_epg_data = self._get_consolidated_epg_data()
        found_channels = []
        for normalized_key, sources in content_map.items():
            if not sources: continue
            best_matching_name = next((s['name'] for s in sources if all(term in self._normalize_for_search(s['name']) for term in search_terms)), None)
            if best_matching_name:
                found_channels.append({'channel_name_variants': best_matching_name, 'sources': sources, 'channel_logo': '', 'pid': None, 'api_epg_processed': {}, 'xml_epg_data': xml_epg_data})
        if not found_channels:
            xbmcgui.Dialog().notification('Busca', f'Nenhum resultado para "{query_text}"', xbmcgui.NOTIFICATION_INFO, 3000)
        else:
            for channel_data in found_channels:
                self._create_live_channel_list_item(**channel_data)
        xbmcplugin.endOfDirectory(self.handle)

    def _list_live_channels(self, url):
        map_filepath = os.path.join(self.maps_cache_path, 'live_map.json')
        if not xbmcvfs.exists(map_filepath):
            xbmcgui.Dialog().notification('Aguarde', 'Análise de canais em andamento...', xbmcgui.NOTIFICATION_INFO, 3000)
            return
        with xbmcvfs.File(map_filepath, 'r') as f: content_map = json.load(f)
        provider_data = self.get_json_from_url(url, cache_duration_hours=6)
        if not provider_data or not provider_data.get('userChannels'): return
        api_pids_to_fetch = [c.get('pid') for c in provider_data.get('userChannels', []) if c.get('pid') and c.get('pid') != '0']
        api_epg_processed = self._process_raw_epg(self._get_raw_epg_for_pids(api_pids_to_fetch))
        xml_epg_data = self._get_consolidated_epg_data()
        for channel in provider_data.get('userChannels', []):
            channel_name_variants = channel.get('ChannelName')
            if not channel_name_variants: continue
            sources = None
            for name_variant in channel_name_variants.split(','):
                normalized_name = self._normalize_title(name_variant.strip())
                if normalized_name in content_map:
                    sources = content_map[normalized_name]
                    break
            if sources:
                self._create_live_channel_list_item(channel_name_variants=channel_name_variants, sources=sources, channel_logo=channel.get('image', {}).get('url'), pid=channel.get('pid'), api_epg_processed=api_epg_processed, xml_epg_data=xml_epg_data)
        xbmcplugin.endOfDirectory(self.handle)

    def _list_filtered_content(self, url, parent_id, map_filename, media_type):
        map_filepath = os.path.join(self.maps_cache_path, map_filename)
        if not xbmcvfs.exists(map_filepath):
            xbmcgui.Dialog().notification('Aguarde', 'Análise de mídias em andamento.', xbmcgui.NOTIFICATION_INFO, 5000)
            return
        with xbmcvfs.File(map_filepath, 'r') as f: content_map = json.load(f)
        if '{realizarbusca}' in url:
            keyboard = xbmc.Keyboard('', 'Pesquisar')
            keyboard.doModal()
            if not (keyboard.isConfirmed() and keyboard.getText()): return
            url = url.replace('{realizarbusca}', urllib.parse.quote_plus(keyboard.getText()))
        valid_items, url_parts = [], list(urllib.parse.urlparse(url))
        query_params = dict(urllib.parse.parse_qsl(url_parts[4]))
        current_page, last_api_data = int(query_params.get('page', 1)), {}
        while len(valid_items) < 20:
            query_params['page'] = str(current_page)
            url_parts[4] = urllib.parse.urlencode(query_params)
            api_data = self.get_json_from_url(urllib.parse.urlunparse(url_parts))
            if not api_data or not api_data.get('results'): break
            last_api_data = api_data
            for item in api_data['results']:
                title = item.get('title') or item.get('name')
                if title:
                    sources = content_map.get(self._normalize_title(title))
                    if sources:
                        valid_items.append((item, sources))
                        if len(valid_items) == 20: break
            if len(valid_items) == 20 or current_page >= api_data.get('total_pages', 1): break
            current_page += 1
        for item, sources in valid_items:
            self._create_list_item(item, media_type, sources)
        if len(valid_items) == 20 and 'total_pages' in last_api_data and current_page < last_api_data.get('total_pages', 1):
            query_params['page'] = str(current_page + 1)
            url_parts[4] = urllib.parse.urlencode(query_params)
            next_api_url = urllib.parse.urlunparse(url_parts)
            next_page_li = xbmcgui.ListItem('Próxima Página')
            next_page_li.setArt({'icon': NEXT_PAGE_ICON, 'thumb': NEXT_PAGE_ICON})
            next_page_url = self._get_plugin_url(action='list_content', url=next_api_url, parent_id=parent_id)
            xbmcplugin.addDirectoryItem(handle=self.handle, url=next_page_url, listitem=next_page_li, isFolder=True)
        xbmcplugin.endOfDirectory(self.handle)

    def _create_list_item(self, item, mediatype, sources=None):
        title = item.get('title') if mediatype == 'movie' else item.get('name')
        li = xbmcgui.ListItem(title)
        if sources:
            li.setProperty('IsPlayable', 'true' if mediatype == 'movie' else 'false')
        poster = TMDB_IMAGE_BASE_URL + 'w500' + item.get('poster_path', '') if item.get('poster_path') else ''
        fanart = TMDB_IMAGE_BASE_URL + 'original' + item.get('backdrop_path', '') if item.get('backdrop_path') else ''
        li.setArt({'thumb': poster, 'icon': poster, 'fanart': fanart})
        premiered = item.get('release_date') if mediatype == 'movie' else item.get('first_air_date')
        year = int(premiered.split('-')[0]) if premiered else 0
        li.setInfo('video', {'title': title, 'plot': item.get('overview'), 'year': year, 'premiered': premiered, 'rating': item.get('vote_average'), 'mediatype': mediatype})
        if mediatype == 'movie' and sources:
            action, params = 'play_item', {'item_type': 'movie', 'sources_json': json.dumps(sources), 'title': title}
        elif mediatype == 'tv' and sources:
            action, params = 'list_episodes', {'series_id': sources[0]['id'], 'tmdb_id': item.get('id'), 'title': title}
        else:
            action, params = 'play_item', {'sources_json': None, 'title': title}
        play_url = self._get_plugin_url(action=action, **params)
        is_folder = (mediatype == 'tv' and sources is not None)
        xbmcplugin.addDirectoryItem(handle=self.handle, url=play_url, listitem=li, isFolder=is_folder)

    def _list_seasons_for_series(self, series_id, tmdb_id, title, provider_data):
        tmdb_series_url = f"https://api.themoviedb.org/3/tv/{tmdb_id}?api_key={self.TMDB_API_KEY}&language=pt-BR"
        tmdb_series_data = self.get_json_from_url(tmdb_series_url, cache_duration_hours=24)
        tmdb_seasons_map = {s['season_number']: s for s in tmdb_series_data.get('seasons', [])} if tmdb_series_data else {}
        provider_season_numbers = {s.get('season_number') for s in provider_data.get('seasons', []) if s.get('season_number') is not None}
        episode_season_numbers = {int(s_num) for s_num in provider_data.get('episodes', {}).keys() if s_num.isdigit()}
        all_season_numbers = sorted(list(provider_season_numbers.union(episode_season_numbers)))
        if not all_season_numbers:
            xbmcgui.Dialog().notification('Nenhuma Temporada', 'Nenhuma temporada foi encontrada.', xbmcgui.NOTIFICATION_INFO, 5000)
            return
        series_fanart = TMDB_IMAGE_BASE_URL + 'original' + tmdb_series_data.get('backdrop_path', '') if tmdb_series_data and tmdb_series_data.get('backdrop_path') else ''
        for season_num in all_season_numbers:
            tmdb_season = tmdb_seasons_map.get(season_num, {})
            season_name = tmdb_season.get('name', f"Temporada {season_num}")
            season_poster_path = tmdb_season.get('poster_path') or (tmdb_series_data.get('poster_path') if tmdb_series_data else None)
            season_poster = TMDB_IMAGE_BASE_URL + 'w500' + season_poster_path if season_poster_path else ''
            li = xbmcgui.ListItem(label=season_name)
            li.setArt({'poster': season_poster, 'thumb': season_poster, 'icon': season_poster, 'fanart': series_fanart})
            li.setInfo('video', {'title': season_name, 'plot': tmdb_season.get('overview')})
            url = self._get_plugin_url(action='list_episodes', series_id=series_id, tmdb_id=tmdb_id, title=title, season_number=season_num)
            xbmcplugin.addDirectoryItem(handle=self.handle, url=url, listitem=li, isFolder=True)
            
    def _list_episodes_for_season(self, series_id, tmdb_id, title, season_number, provider_data):
        tmdb_season_url = f"https://api.themoviedb.org/3/tv/{tmdb_id}/season/{season_number}?api_key={self.TMDB_API_KEY}&language=pt-BR"
        tmdb_season_data = self.get_json_from_url(tmdb_season_url, cache_duration_hours=24)
        tmdb_episodes_map = {e['episode_number']: e for e in tmdb_season_data.get('episodes', [])} if tmdb_season_data else {}
        provider_episodes = provider_data.get('episodes', {}).get(str(season_number), [])
        series_fanart = TMDB_IMAGE_BASE_URL + 'original' + tmdb_season_data.get('poster_path', '') if tmdb_season_data and tmdb_season_data.get('poster_path') else ''
        for ep_provider in provider_episodes:
            ep_num = int(ep_provider.get('episode_num', 0))
            ep_tmdb = tmdb_episodes_map.get(ep_num, {})
            ep_title = ep_tmdb.get('name', ep_provider.get('title', f"Episódio {ep_num}"))
            ep_plot = ep_tmdb.get('overview', ep_provider.get('info', {}).get('plot'))
            ep_thumb = TMDB_IMAGE_BASE_URL + 'original' + ep_tmdb.get('still_path', '') if ep_tmdb.get('still_path') else series_fanart
            li = xbmcgui.ListItem(label=f'{ep_num}. {ep_title}')
            li.setProperty('IsPlayable', 'true')
            li.setArt({'icon': ep_thumb, 'thumb': ep_thumb, 'fanart': series_fanart})
            li.setInfo('video', {'title': ep_title, 'plot': ep_plot, 'season': ep_provider.get('season'), 'episode': ep_num, 'duration': ep_provider.get('info', {}).get('duration_secs'), 'premiered': ep_tmdb.get('air_date')})
            url = self._get_plugin_url(action='play_item', item_type='series', item_id=ep_provider.get('id'), title=f"{title} - {ep_title}")
            xbmcplugin.addDirectoryItem(handle=self.handle, url=url, listitem=li, isFolder=False)
            
    def list_episodes(self, series_id, tmdb_id, title, season_number=None):
        xbmcplugin.setContent(self.handle, 'episodes' if season_number else 'seasons')
        provider_url = f"{self.CINEPULSE_BASE_API}get_series_info&series_id={series_id}"
        provider_data = self.get_json_from_url(provider_url, cache_duration_hours=6)
        if not provider_data:
            xbmcgui.Dialog().notification('Erro', 'Não foi possível carregar as info da série.', xbmcgui.NOTIFICATION_ERROR, 5000)
            return
        if not season_number:
            self._list_seasons_for_series(series_id, tmdb_id, title, provider_data)
        else:
            self._list_episodes_for_season(series_id, tmdb_id, title, season_number, provider_data)
        xbmcplugin.endOfDirectory(self.handle)

    def list_epg_for_channel(self, channel_name):
        xbmcplugin.setContent(self.handle, 'episodes')
        epg_data = self._get_consolidated_epg_data()
        schedule = []
        for name_variant in channel_name.split(','):
            normalized_name = self._normalize_title(name_variant.strip())
            if normalized_name in epg_data:
                schedule = epg_data[normalized_name]
                break
        if not schedule:
            xbmcgui.Dialog().ok("Guia de Programação", "Nenhuma programação encontrada para este canal.")
            return
        now = datetime.now(timezone.utc)
        for program in schedule:
            start_time = datetime.fromisoformat(program['start_str'])
            if start_time.date() > now.date() + timedelta(days=1): continue
            label = f"[B]{start_time.astimezone().strftime('%H:%M')}[/B] - {program['title']}"
            li = xbmcgui.ListItem(label=label)
            li.setInfo('video', {'title': program['title'], 'plot': program['description']})
            li.setArt({'icon': program.get('icon')})
            li.setProperty('IsPlayable', 'false')
            xbmcplugin.addDirectoryItem(handle=self.handle, url='', listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(self.handle)
    
    def _handle_source_selection(self, sources_json):
        try:
            sources = json.loads(sources_json)
            if not sources: return None
            if len(sources) == 1: return sources[0]['id']
            options = [source['name'] for source in sources]
            choice_index = xbmcgui.Dialog().select('Múltiplas fontes, escolha uma:', options)
            return sources[choice_index]['id'] if choice_index > -1 else None
        except (json.JSONDecodeError, TypeError):
            return None

    def _show_playback_overlay(self):
        xbmc.sleep(1500)
        video_overlay_window = xbmcgui.Window(12005)
        qr_width, qr_height, qr_margin = 130, 165, 20
        try:
            screen_width = int(xbmc.getInfoLabel("System.ScreenWidth"))
            screen_height = int(xbmc.getInfoLabel("System.ScreenHeight"))
            pos_x, pos_y = screen_width - qr_width - qr_margin, screen_height - qr_height - qr_margin
            qr_control = xbmcgui.ControlImage(pos_x, pos_y, qr_width, qr_height, QR_CODE_ICON)
            video_overlay_window.addControl(qr_control)
        except Exception as e:
            xbmc.log(f"Error creating QR Code overlay: {e}", level=xbmc.LOGERROR)

    def _resolve_dns(self, url, headers=None):
        headers = headers or {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
        url = url.replace('https://', 'http://')
        parsed_url = urllib.parse.urlparse(url)
        host = parsed_url.hostname
        if not host or re.match(r'^(\d{1,3}\.){3}\d{1,3}(:\d+)?$', host):
            return {'url': url, 'headers': headers}
        params = {"name": host, "type": "A"}
        try:
            response = requests.get('https://cloudflare-dns.com/dns-query', headers={"Accept": "application/dns-json"}, params=params, timeout=2).json()
            ip = response.get('Answer', [{}])[-1].get('data', host)
        except Exception:
            ip = host
        port_str = f":{parsed_url.port}" if parsed_url.port else ""
        new_host = f"{parsed_url.scheme}://{ip}{port_str}"
        original_host = f"{parsed_url.scheme}://{host}{port_str}"
        url_replace = url.replace(original_host, new_host)
        headers['Host'] = host
        return {'url': url_replace, 'headers': headers}

    def get_redirect_url(self, url, headers=None):
        try:
            response = requests.get(url, headers=headers or {}, allow_redirects=False, timeout=5)
            return response.headers.get("Location", url) if response.is_redirect else url
        except Exception:
            return url

    def _play_stream(self, stream_id, title, base_url_template):
        if not stream_id:
            xbmcgui.Dialog().notification('Erro', 'ID da mídia não encontrado.', xbmcgui.NOTIFICATION_ERROR, 3000)
            return
        initial_url = base_url_template.format(id=stream_id)
        dns_result = self._resolve_dns(initial_url)
        if not dns_result or not dns_result.get('url'):
            xbmcgui.Dialog().notification('Erro de DNS', 'Não foi possível resolver o host.', xbmcgui.NOTIFICATION_ERROR, 3000)
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return
        final_url = self.get_redirect_url(dns_result['url'], dns_result['headers'])
        if not final_url:
            xbmcgui.Dialog().notification('Erro de Redirect', 'Não foi possível obter a URL final.', xbmcgui.NOTIFICATION_ERROR, 3000)
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return
        stream_headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
        headers_str = urllib.parse.urlencode(stream_headers)
        path = f"{final_url}|{headers_str}"
        li = xbmcgui.ListItem(path=path)
        li.setInfo('video', {'title': title})
        li.setProperty('IsPlayable', 'true')
        mimetype = 'video/mp4' if final_url.endswith('.mp4') else 'video/mp2t'
        li.setProperty('inputstream', 'inputstream.ffmpegdirect')
        li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
        li.setProperty('mimetype', mimetype)
        xbmcplugin.setResolvedUrl(self.handle, True, li)
        self._show_playback_overlay()
    
    def play_item(self, item_type, title, sources_json=None, item_id=None):
        chosen_id = item_id if item_id else self._handle_source_selection(sources_json)
        if chosen_id:
            base_url = self.PLAY_URL_TEMPLATES.get(item_type)
            if base_url:
                self._play_stream(chosen_id, title, base_url)
            else:
                xbmc.log(f"Invalid item_type for playback: {item_type}", level=xbmc.LOGERROR)

    def _get_plugin_url(self, **kwargs):
        return f"{self.base_url}?{urllib.parse.urlencode({k: v for k, v in kwargs.items() if v is not None})}"

    def run(self):
        if not self.is_initialized:
            return
        
        action = self.params.get('action')
        if action == 'list_epg_for_channel':
            self.list_epg_for_channel(self.params.get('channel_name'))
        elif action == 'search_all_live':
            self.search_all_live()
        elif action == 'list_subcategories':
            self.list_subcategories(self.params.get('url'), self.params.get('parent_id'))
        elif action == 'list_content':
            self.list_content(self.params.get('url'), self.params.get('parent_id'))
        elif action == 'list_episodes':
            self.list_episodes(self.params.get('series_id'), self.params.get('tmdb_id'), self.params.get('title'), self.params.get('season_number'))
        elif action == 'play_item':
            self.play_item(item_type=self.params.get('item_type'), title=self.params.get('title'), sources_json=self.params.get('sources_json'), item_id=self.params.get('item_id'))
        else:
            self.list_categories()

if __name__ == '__main__':
    addon = Addon(sys.argv)
    addon.run()